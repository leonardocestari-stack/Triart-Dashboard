import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { NamedValue, SeriesPoint } from "@/lib/dashboard-types";
import { EmptyState } from "./panel";

const AXIS = {
  stroke: "var(--mute)",
  fontSize: 11,
  fontWeight: 600,
} as const;

const tooltipStyle = {
  borderRadius: 8,
  border: "1px solid var(--border)",
  boxShadow: "var(--shadow-soft)",
  fontSize: 12,
  fontWeight: 600,
} as const;

export const PIE_COLORS = [
  "var(--brand)",
  "var(--peach)",
  "var(--sky)",
  "var(--mint)",
  "var(--butter)",
  "var(--rose)",
  "var(--brand-deep)",
];

function hasData(points: { value: number | null }[]) {
  return points.some((p) => p.value !== null && !Number.isNaN(p.value));
}

export function TrendLine({
  data,
  meta,
  unit = "%",
  color = "var(--brand)",
  height = 260,
}: {
  data: SeriesPoint[];
  meta?: number;
  unit?: string;
  color?: string;
  height?: number;
}) {
  if (!hasData(data)) return <EmptyState />;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
        <CartesianGrid strokeDasharray="4 6" stroke="var(--border)" vertical={false} />
        <XAxis dataKey="label" tickLine={false} axisLine={false} tick={AXIS} />
        <YAxis tickLine={false} axisLine={false} tick={AXIS} width={52} />
        <Tooltip
          contentStyle={tooltipStyle}
          formatter={(v: number) => [`${v.toLocaleString("pt-BR")}${unit}`, "Valor"]}
        />
        {meta !== undefined ? (
          <ReferenceLine
            y={meta}
            stroke="var(--bad)"
            strokeDasharray="6 6"
            label={{
              value: `Meta ${meta}${unit}`,
              position: "insideTopRight",
              fill: "var(--bad)",
              fontSize: 11,
              fontWeight: 700,
            }}
          />
        ) : null}
        <Line
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={3}
          dot={{ r: 4, fill: color, strokeWidth: 0 }}
          activeDot={{ r: 6 }}
          connectNulls
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function Columns({
  data,
  meta,
  metaDirecao = "max",
  unit = "",
  color = "var(--brand)",
  height = 260,
}: {
  data: NamedValue[];
  meta?: number;
  /** "max": valores devem ficar abaixo da meta. "min": devem ficar acima. */
  metaDirecao?: "max" | "min";
  unit?: string;
  color?: string;
  height?: number;
}) {
  if (!data.length) return <EmptyState />;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
        <CartesianGrid strokeDasharray="4 6" stroke="var(--border)" vertical={false} />
        <XAxis dataKey="label" tickLine={false} axisLine={false} tick={AXIS} />
        <YAxis tickLine={false} axisLine={false} tick={AXIS} width={52} />
        <Tooltip
          cursor={{ fill: "var(--muted)" }}
          contentStyle={tooltipStyle}
          formatter={(v: number) => [`${v.toLocaleString("pt-BR")}${unit}`, "Valor"]}
        />
        {meta !== undefined ? (
          <ReferenceLine
            y={meta}
            stroke="var(--bad)"
            strokeDasharray="6 6"
            label={{
              value: `Meta ${meta}${unit}`,
              position: "insideTopRight",
              fill: "var(--bad)",
              fontSize: 11,
              fontWeight: 700,
            }}
          />
        ) : null}
        <Bar dataKey="value" radius={[12, 12, 6, 6]}>
          {data.map((d, i) => (
            <Cell
              key={d.label}
              fill={
                meta !== undefined &&
                (metaDirecao === "max" ? d.value > meta : d.value < meta)
                  ? "var(--bad)"
                  : color
              }
              opacity={meta !== undefined ? 1 : 0.55 + (0.45 * (i + 1)) / data.length}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function Donut({
  data,
  formatter,
  height = 260,
}: {
  data: NamedValue[];
  formatter?: (v: number) => string;
  height?: number;
}) {
  if (!data.length || data.every((d) => !d.value)) return <EmptyState />;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="label"
          innerRadius="52%"
          outerRadius="80%"
          paddingAngle={2}
          stroke="var(--card)"
          strokeWidth={3}
        >
          {data.map((d, i) => (
            <Cell key={d.label} fill={PIE_COLORS[i % PIE_COLORS.length]} />
          ))}
        </Pie>
        <Tooltip
          contentStyle={tooltipStyle}
          formatter={(v: number, n: string) => [formatter ? formatter(v) : v.toLocaleString("pt-BR"), n]}
        />
        <Legend
          verticalAlign="bottom"
          iconType="circle"
          formatter={(value: string) => (
            <span style={{ color: "var(--ink)", fontSize: 12, fontWeight: 600 }}>{value}</span>
          )}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}
