import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Panel({
  title,
  subtitle,
  badge,
  className,
  children,
}: {
  title: string;
  subtitle?: string;
  badge?: ReactNode;
  className?: string;
  children: ReactNode;
}) {
  return (
    <section className={cn("card-soft p-5 sm:p-6", className)}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="head text-lg font-bold">{title}</h2>
          {subtitle ? <p className="text-xs font-semibold text-mute">{subtitle}</p> : null}
        </div>
        {badge}
      </div>
      <div className="mt-6">{children}</div>
    </section>
  );
}

export function MetaBadge({ children }: { children: ReactNode }) {
  return (
    <span className="rounded-md bg-brand/10 px-3 py-1 text-xs font-bold whitespace-nowrap text-brand">
      {children}
    </span>
  );
}

export function EmptyState({ message = "Sem dados preenchidos na planilha ainda." }: { message?: string }) {
  return (
    <div className="flex h-52 flex-col items-center justify-center rounded-lg border border-dashed border-border bg-secondary/60 px-5 text-center">
      <p className="text-sm font-semibold text-mute">{message}</p>
      <p className="mt-1 text-xs text-mute">
        Assim que a base for preenchida, o gráfico aparece aqui automaticamente.
      </p>
    </div>
  );
}

export function KpiCard({
  icon,
  tone = "brand",
  label,
  value,
  hint,
  status,
}: {
  icon: ReactNode;
  tone?: "brand" | "peach" | "sky" | "mint" | "butter";
  label: string;
  value: string;
  hint?: string;
  status?: "good" | "bad" | null;
}) {
  const toneBg = {
    brand: "bg-primary-foreground/15 text-primary-foreground",
    peach: "bg-peach/40",
    sky: "bg-sky/30",
    mint: "bg-mint/30",
    butter: "bg-butter/40",
  }[tone];

  return (
    <div
      className={cn(
        "card-soft p-5 transition-transform duration-200 hover:-translate-y-0.5",
        tone === "brand" && "border-brand bg-brand text-primary-foreground shadow-[var(--shadow-lift)]",
      )}
    >
      <div className="flex items-center justify-between">
        <span className={cn("flex h-11 w-11 items-center justify-center rounded-lg text-brand", toneBg)}>{icon}</span>
        {status ? (
          <span
            className={cn(
              "rounded-md px-2 py-1 text-xs font-bold",
              status === "good" ? "bg-mint/25 text-good" : "bg-rose/25 text-bad",
              tone === "brand" && "bg-primary-foreground/15 text-primary-foreground",
            )}
          >
            {status === "good" ? "Na meta" : "Fora da meta"}
          </span>
        ) : null}
      </div>
      <p className={cn("mt-4 text-xs font-semibold text-mute", tone === "brand" && "text-primary-foreground/80")}>{label}</p>
      <p className="head text-3xl font-bold">{value}</p>
      {hint ? <p className={cn("mt-1 text-xs font-semibold text-mute", tone === "brand" && "text-primary-foreground/75")}>{hint}</p> : null}
    </div>
  );
}
