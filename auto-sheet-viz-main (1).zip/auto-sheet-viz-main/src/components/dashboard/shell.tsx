import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Factory, FolderOpen, LayoutDashboard, Users, Wallet } from "lucide-react";
import logoAsset from "@/assets/triart-logo.png.asset.json";
import { horario } from "./format";

const AREAS = [
  { to: "/", label: "Visão Geral", icon: LayoutDashboard },
  { to: "/comercial", label: "Comercial", icon: Wallet },
  { to: "/projetos", label: "Projetos", icon: FolderOpen },
  { to: "/producao", label: "Produção", icon: Factory },
  { to: "/rh", label: "RH", icon: Users },
] as const;

export function Shell({
  atualizadoEm,
  children,
}: {
  atualizadoEm: string;
  children: ReactNode;
}) {
  return (
    <div className="min-h-screen bg-background text-foreground md:grid md:grid-cols-[240px_minmax(0,1fr)]">
      <aside className="hidden border-r border-border bg-card md:sticky md:top-0 md:flex md:h-screen md:flex-col md:px-5 md:py-7">
        <img src={logoAsset.url} alt="Triart estandes e eventos" className="h-auto w-40" />
        <p className="mt-8 px-3 text-xs font-semibold uppercase text-mute">Painel executivo</p>
        <nav className="mt-3 space-y-1" aria-label="Áreas do painel">
          {AREAS.map((area) => {
            const Icon = area.icon;
            return (
              <Link
                key={area.to}
                to={area.to}
                className="flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-semibold text-mute transition-colors hover:bg-accent hover:text-ink"
                activeProps={{ className: "bg-brand text-primary-foreground shadow-[var(--shadow-lift)]" }}
                activeOptions={{ exact: area.to === "/" }}
              >
                <Icon className="h-4 w-4" />
                {area.label}
              </Link>
            );
          })}
        </nav>
        <div className="mt-auto border-t border-border pt-5">
          <div className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-3">
            <span className="h-2 w-2 animate-pulse rounded-full bg-brand" />
            <div>
              <p className="text-xs font-semibold text-ink">Base sincronizada</p>
              <p className="mt-0.5 text-xs text-mute">{horario(atualizadoEm)}</p>
            </div>
          </div>
        </div>
      </aside>

      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/90 px-5 backdrop-blur-md md:hidden">
          <img src={logoAsset.url} alt="Triart estandes e eventos" className="h-auto w-28" />
          <div className="flex items-center gap-2 text-xs font-semibold text-mute">
            <span className="h-2 w-2 animate-pulse rounded-full bg-brand" />
            {horario(atualizadoEm)}
          </div>
        </header>
        <main className="mx-auto max-w-[1440px] px-4 pb-28 sm:px-6 md:px-8 md:pb-12 lg:px-10">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 grid h-20 grid-cols-5 border-t border-border bg-card px-2 md:hidden" aria-label="Áreas do painel">
        {AREAS.map((area) => {
          const Icon = area.icon;
          return (
            <Link
              key={area.to}
              to={area.to}
              className="flex min-w-0 flex-col items-center justify-center gap-1 text-[10px] font-semibold text-mute"
              activeProps={{ className: "text-brand" }}
              activeOptions={{ exact: area.to === "/" }}
            >
              <Icon className="h-5 w-5" />
              <span className="max-w-full truncate">{area.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

export function PageTitle({ title, description }: { title: string; description: string }) {
  return (
    <div className="pt-7 md:pt-10">
      <p className="mb-2 text-xs font-semibold uppercase text-brand">Triart · Indicadores 2026</p>
      <h1 className="head text-3xl font-bold sm:text-4xl">{title}</h1>
      <p className="mt-2 max-w-3xl text-sm font-medium leading-6 text-mute">{description}</p>
    </div>
  );
}
