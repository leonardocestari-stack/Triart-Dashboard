import { queryOptions } from "@tanstack/react-query";
import { getDashboard } from "./dashboard.functions";

export const REFRESH_MS = 5 * 60 * 1000;

export const dashboardQuery = queryOptions({
  queryKey: ["dashboard"],
  queryFn: () => getDashboard(),
  staleTime: REFRESH_MS,
  refetchInterval: REFRESH_MS,
  refetchOnWindowFocus: true,
});
