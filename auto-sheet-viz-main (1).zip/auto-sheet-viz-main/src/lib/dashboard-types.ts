export type SeriesPoint = { label: string; value: number | null };
export type NamedValue = { label: string; value: number };

export type ComercialData = {
  totalLeads: number;
  convertidos: number;
  perdidos: number;
  taxaConversao: number | null;
  propostasEnviadas: number;
  valorPropostas: number;
  valorVendas: number;
  tempoMedioFechamento: number | null;
  conversaoPorMes: SeriesPoint[];
  propostasPorMes: NamedValue[];
  valorPropostasPorMes: NamedValue[];
  tempoFechamentoPorMes: SeriesPoint[];
};

export type ProjetosData = {
  solicitados: number;
  finalizados: number;
  alteracoes: number;
  percFinalizados: number | null;
  percPorMes: SeriesPoint[];
  alteracoesPorMes: NamedValue[];
};

export type EstoqueArea = {
  nome: string;
  meta: number;
  atual: number | null;
  media: number | null;
  serie: SeriesPoint[];
};

export type ProducaoData = {
  areas: EstoqueArea[];
  perdas: NamedValue[];
  perdasMeta: number;
  acuracidadeMedia: number | null;
  perdasMedia: number | null;
};

export type RhIndicador = {
  nome: string;
  meta: number | null;
  media: number | null;
  atual: number | null;
  percentual: boolean;
  serie: SeriesPoint[];
};

export type RhData = {
  turnover: RhIndicador | null;
  absenteismo: RhIndicador | null;
  outros: RhIndicador[];
  bimestrais: RhIndicador[];
  anuais: RhIndicador[];
  feedbackMedia: number | null;
  feedbackMeta: number | null;
  pco: RhIndicador | null;
};

export type DashboardData = {
  atualizadoEm: string;
  comercial: ComercialData;
  projetos: ProjetosData;
  producao: ProducaoData;
  rh: RhData;
};

export const METAS = {
  conversao: 70,
  acuracidade: 95,
  perdas: 5,
  turnover: 3,
  absenteismo: 3,
  feedbacks: 100,
  pco: 80,
} as const;
