import { createServerFn } from "@tanstack/react-start";
import type { DashboardData } from "./dashboard-types";

export const getDashboard = createServerFn({ method: "GET" }).handler(
  async (): Promise<DashboardData> => {
    const { loadDashboard } = await import("./sheets.server");
    return loadDashboard();
  },
);
