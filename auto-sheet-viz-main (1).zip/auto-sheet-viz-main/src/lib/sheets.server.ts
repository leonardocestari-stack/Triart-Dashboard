import type {
  ComercialData,
  DashboardData,
  EstoqueArea,
  NamedValue,
  ProducaoData,
  ProjetosData,
  RhData,
  RhIndicador,
  SeriesPoint,
} from "./dashboard-types";
import { METAS } from "./dashboard-types";

/** Cada área vive em uma planilha própria: [id do arquivo, gid da aba]. */
type Source = { id: string; gid: string };

const DOC = {
  comercial: "1X2IUUECJbPHMqNMoEl5CJdWI2g-py_7M",
  projetos: "1ilNH9bdma018fkyyHXOREeKpQ2XGCfGm",
  rh: "1VwzG0M9N-uQmL2SLiFgf0Wye9bJcl6BK",
  producao: "1VrZK6veBexCBhq6dq1pKevGEG0Fcmcx4",
} as const;

/** Abas de dashboard (uma por área), cada uma com várias seções. */
const SOURCES = {
  comercial: { id: DOC.comercial, gid: "435590028" },
  projetos: { id: DOC.projetos, gid: "148186367" },
  producao: { id: DOC.producao, gid: "1001078633" },
  rh: { id: DOC.rh, gid: "2137951986" },
} as const satisfies Record<string, Source>;

type Grid = string[][];

const lastGood = new Map<string, Grid>();
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// O Google limita rajadas de leitura (429). Tenta algumas vezes e, se ainda
// falhar, devolve a última leitura boa daquela aba (ou vazio) em vez de
// derrubar o painel inteiro.
async function fetchTab(src: Source): Promise<Grid> {
  const key = `${src.id}:${src.gid}`;
  const url = `https://docs.google.com/spreadsheets/d/${src.id}/export?format=csv&gid=${src.gid}`;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const res = await fetch(url, { headers: { "cache-control": "no-cache" } });
      if (res.ok) {
        const grid = parseCsv(await res.text());
        lastGood.set(key, grid);
        return grid;
      }
      if (res.status !== 429 && res.status < 500) break;
    } catch {
      // rede instável: tenta de novo
    }
    await sleep(600 * (attempt + 1));
  }
  return lastGood.get(key) ?? [];
}

async function fetchTabsSequential(sources: Source[]): Promise<Grid[]> {
  const out: Grid[] = [];
  for (const s of sources) out.push(await fetchTab(s));
  return out;
}

export function parseCsv(text: string): Grid {
  const rows: Grid = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else quoted = false;
      } else field += c;
      continue;
    }
    if (c === '"') quoted = true;
    else if (c === ",") {
      row.push(field);
      field = "";
    } else if (c === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else if (c !== "\r") field += c;
  }
  row.push(field);
  rows.push(row);
  return rows;
}

/* ---------- value helpers ---------- */

function clean(v: string | undefined): string {
  return (v ?? "").trim();
}

/** Parses Brazilian formatted numbers: "15.000,00", "92,5%", "95%", "20". */
export function num(v: string | undefined): number | null {
  let s = clean(v);
  if (!s) return null;
  s = s.replace(/[R$\s%]/g, "");
  if (s.includes(",")) s = s.replace(/\./g, "").replace(",", ".");
  else if (/^-?\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, "");
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

/** Percent values may be stored as 0-1 fractions or as 0-100. */
function pct(v: string | undefined): number | null {
  const raw = clean(v);
  const n = num(raw);
  if (n === null) return null;
  if (!raw.includes("%") && n > 0 && n <= 1) return n * 100;
  return n;
}

export function parseDate(v: string | undefined): Date | null {
  const s = clean(v);
  if (!s) return null;
  const m = s.match(/^(\d{1,4})[/-](\d{1,2})[/-](\d{2,4})$/);
  if (!m) {
    const d = new Date(s);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const a = m[1] as string;
  const b = m[2] as string;
  const c = m[3] as string;
  let day: number, month: number, year: number;
  if (a.length === 4) {
    year = +a;
    month = +b;
    day = +c;
  } else if (+a > 12) {
    day = +a;
    month = +b;
    year = +c;
  } else if (+b > 12) {
    month = +a;
    day = +b;
    year = +c;
  } else {
    if (c.length === 2) {
      day = +a;
      month = +b;
    } else {
      month = +a;
      day = +b;
    }
    year = +c;
  }
  if (year < 100) year += 2000;
  const d = new Date(Date.UTC(year, month - 1, day));
  return Number.isNaN(d.getTime()) ? null : d;
}

const MESES_CURTOS = [
  "Jan",
  "Fev",
  "Mar",
  "Abr",
  "Mai",
  "Jun",
  "Jul",
  "Ago",
  "Set",
  "Out",
  "Nov",
  "Dez",
];
const MESES_LONGOS = [
  "janeiro",
  "fevereiro",
  "março",
  "abril",
  "maio",
  "junho",
  "julho",
  "agosto",
  "setembro",
  "outubro",
  "novembro",
  "dezembro",
];

function monthLabel(key: string): string {
  const [y = "", m = "1"] = key.split("-");
  return `${MESES_CURTOS[+m - 1] ?? m}/${y.slice(2)}`;
}

/** "Janeiro/2026" | "Jan/2026" | "jan./26" -> chave ordenável */
function monthKeyFromText(v: string | undefined): string | null {
  const s = clean(v).toLowerCase().replace(/\./g, "");
  if (!s) return null;
  const m = s.match(/^([a-zçã]+)[/\s-]+(\d{2,4})$/i);
  if (!m) return null;
  const nome = (m[1] ?? "").slice(0, 3);
  const idx = MESES_LONGOS.findIndex((n) => n.startsWith(nome));
  if (idx < 0) return null;
  let year = Number(m[2] ?? "");
  if (year < 100) year += 2000;
  return `${year}-${String(idx + 1).padStart(2, "0")}`;
}

/** "Agora" no fuso de operação da empresa (São Paulo), não no fuso do servidor. */
function nowBr(): { year: number; month: number } {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
  }).format(new Date());
  const [y = "1970", m = "01"] = parts.split("-");
  return { year: +y, month: +m };
}

function currentMonthKey(): string {
  const { year, month } = nowBr();
  return `${year}-${String(month).padStart(2, "0")}`;
}

/**
 * Valor "atual" = o do mês corrente. Se o mês corrente ainda não foi preenchido,
 * usa o período preenchido mais recente ANTES dele (nunca meses futuros).
 */
function atualDaData(pontos: { key: string | null; value: number | null }[]): number | null {
  const hoje = currentMonthKey();
  const corrente = pontos.find((p) => p.key === hoje);
  if (corrente && corrente.value !== null) return corrente.value;
  let out: number | null = null;
  for (const p of pontos) {
    if (p.value === null) continue;
    if (p.key !== null && p.key > hoje) continue;
    out = p.value;
  }
  return out;
}

/** Média dos valores preenchidos (ignora vazios). */
function mediaDe(values: (number | null)[]): number | null {
  const ok = values.filter((v): v is number => v !== null && Number.isFinite(v));
  if (!ok.length) return null;
  return Math.round((ok.reduce((s, v) => s + v, 0) / ok.length) * 10) / 10;
}

/* ---------- section helpers ---------- */

function columnMap(headerRow: string[]): Record<string, number> {
  const map: Record<string, number> = {};
  headerRow.forEach((cell, i) => {
    const key = clean(cell).toLowerCase();
    if (key && !(key in map)) map[key] = i;
  });
  return map;
}

const col = (row: string[], map: Record<string, number>, name: string) => {
  const i = map[name.toLowerCase()];
  return i === undefined ? "" : clean(row[i]);
};

const isBlank = (r: string[] | undefined) => (r ?? []).every((c) => clean(c) === "");

type Section = { map: Record<string, number>; header: string[]; rows: Grid };

/** Coleta as linhas logo após a linha de cabeçalho, até a próxima linha vazia. */
function sectionAt(grid: Grid, headerIndex: number): Section {
  const header = grid[headerIndex] ?? [];
  const rows: Grid = [];
  for (let j = headerIndex + 1; j < grid.length && !isBlank(grid[j]); j++) rows.push(grid[j] ?? []);
  return { map: columnMap(header), header, rows };
}

/** Acha a seção cujo cabeçalho contém todas as colunas informadas. */
function sectionByHeader(grid: Grid, keys: string[], from = 0): Section | null {
  for (let i = from; i < grid.length; i++) {
    const cells = (grid[i] ?? []).map((c) => clean(c).toLowerCase());
    if (keys.every((k) => cells.includes(k.toLowerCase()))) return sectionAt(grid, i);
  }
  return null;
}

/** Acha a seção que vem logo abaixo de um título (ex.: "Sodem - Acuracidade..."). */
function sectionByTitle(grid: Grid, title: RegExp): Section | null {
  for (let i = 0; i < grid.length; i++) {
    const texto = (grid[i] ?? []).map(clean).join(" ");
    if (!title.test(texto)) continue;
    for (let j = i + 1; j < grid.length; j++) {
      if (isBlank(grid[j])) continue;
      return sectionAt(grid, j);
    }
  }
  return null;
}

const ehTotal = (label: string) => /^(total|média|media)/i.test(label.trim());

/* ---------- comercial ---------- */

function parseComercial(grid: Grid): ComercialData {
  const empty: ComercialData = {
    totalLeads: 0,
    convertidos: 0,
    perdidos: 0,
    taxaConversao: null,
    propostasEnviadas: 0,
    valorPropostas: 0,
    valorVendas: 0,
    tempoMedioFechamento: null,
    conversaoPorMes: [],
    propostasPorMes: [],
    valorPropostasPorMes: [],
    tempoFechamentoPorMes: [],
  };

  const leads = sectionByHeader(grid, ["mês de referência", "leads recebidos"]);
  const propostas = sectionByHeader(grid, ["mês de referência", "propostas enviadas"]);
  const tempos = sectionByHeader(grid, ["mês de referência", "tempo médio (dias)"]);
  if (!leads && !propostas && !tempos) return empty;

  let totalLeads = 0;
  let convertidos = 0;
  let perdidos = 0;
  const conversaoPorMes: SeriesPoint[] = [];

  for (const r of leads?.rows ?? []) {
    const mes = col(r, leads!.map, "mês de referência");
    if (!mes || ehTotal(mes)) continue;
    const recebidos = num(col(r, leads!.map, "leads recebidos")) ?? 0;
    const conv = num(col(r, leads!.map, "leads convertidos")) ?? 0;
    const perd = num(col(r, leads!.map, "leads perdidos")) ?? 0;
    totalLeads += recebidos;
    convertidos += conv;
    perdidos += perd;
    const key = monthKeyFromText(mes);
    const taxa = pct(col(r, leads!.map, "taxa de conversão"));
    conversaoPorMes.push({
      label: key ? monthLabel(key) : mes,
      value: taxa ?? (recebidos ? Math.round((conv / recebidos) * 1000) / 10 : null),
    });
  }

  let propostasEnviadas = 0;
  let valorPropostas = 0;
  const propostasPorMes: NamedValue[] = [];
  const valorPropostasPorMes: NamedValue[] = [];

  for (const r of propostas?.rows ?? []) {
    const mes = col(r, propostas!.map, "mês de referência");
    if (!mes || ehTotal(mes)) continue;
    const qtd = num(col(r, propostas!.map, "propostas enviadas")) ?? 0;
    const valor = num(col(r, propostas!.map, "valor total (r$)")) ?? 0;
    const key = monthKeyFromText(mes);
    const label = key ? monthLabel(key) : mes;
    propostasEnviadas += qtd;
    valorPropostas += valor;
    if (qtd) propostasPorMes.push({ label, value: qtd });
    if (valor) valorPropostasPorMes.push({ label, value: valor });
  }

  const tempoFechamentoPorMes: SeriesPoint[] = [];
  let somaTempo = 0;
  let somaNegocios = 0;

  for (const r of tempos?.rows ?? []) {
    const mes = col(r, tempos!.map, "mês de referência");
    if (!mes || ehTotal(mes)) continue;
    const key = monthKeyFromText(mes);
    const medio = num(col(r, tempos!.map, "tempo médio (dias)"));
    const fechados = num(col(r, tempos!.map, "negócios fechados")) ?? 0;
    tempoFechamentoPorMes.push({ label: key ? monthLabel(key) : mes, value: medio });
    if (medio !== null && fechados > 0) {
      somaTempo += medio * fechados;
      somaNegocios += fechados;
    }
  }

  return {
    totalLeads,
    convertidos,
    perdidos,
    taxaConversao: totalLeads ? Math.round((convertidos / totalLeads) * 1000) / 10 : null,
    propostasEnviadas,
    valorPropostas,
    valorVendas: 0,
    tempoMedioFechamento: somaNegocios
      ? Math.round((somaTempo / somaNegocios) * 10) / 10
      : mediaDe(tempoFechamentoPorMes.map((p) => p.value)),
    conversaoPorMes,
    propostasPorMes,
    valorPropostasPorMes,
    tempoFechamentoPorMes,
  };
}

/* ---------- projetos ---------- */

function parseProjetos(grid: Grid): ProjetosData {
  const empty: ProjetosData = {
    solicitados: 0,
    finalizados: 0,
    alteracoes: 0,
    percFinalizados: null,
    percPorMes: [],
    alteracoesPorMes: [],
  };
  const s = sectionByHeader(grid, ["mês", "solicitados", "finalizados"]);
  if (!s) return empty;

  let solicitados = 0;
  let finalizados = 0;
  let alteracoes = 0;
  const percPorMes: SeriesPoint[] = [];
  const alteracoesPorMes: NamedValue[] = [];

  for (const r of s.rows) {
    const mes = col(r, s.map, "mês");
    if (!mes || ehTotal(mes)) continue;
    const key = monthKeyFromText(mes);
    const label = key ? monthLabel(key) : mes;
    const sol = num(col(r, s.map, "solicitados"));
    const fin = num(col(r, s.map, "finalizados"));
    const alt = num(col(r, s.map, "alterações a pedido do cliente"));
    if (sol === null && fin === null && alt === null) continue;
    solicitados += sol ?? 0;
    finalizados += fin ?? 0;
    alteracoes += alt ?? 0;
    const perc = pct(col(r, s.map, "% finalizados"));
    percPorMes.push({ label, value: perc ?? (sol ? Math.round(((fin ?? 0) / sol) * 1000) / 10 : null) });
    if (alt !== null) alteracoesPorMes.push({ label, value: alt });
  }

  return {
    solicitados,
    finalizados,
    alteracoes,
    percFinalizados: solicitados ? Math.round((finalizados / solicitados) * 1000) / 10 : null,
    percPorMes,
    alteracoesPorMes,
  };
}

/* ---------- produção ---------- */

/** Seções "Meta | Realizado | Status" com uma coluna de período variável. */
type Realizado = { serie: SeriesPoint[]; pontos: { key: string | null; value: number | null }[]; meta: number | null; media: number | null };

function lerRealizados(s: Section | null, metaPadrao: number): Realizado {
  if (!s) return { serie: [], pontos: [], meta: metaPadrao, media: null };
  const periodoIdx = s.header.findIndex((c) => clean(c) !== "");
  const serie: SeriesPoint[] = [];
  const pontos: { key: string | null; value: number | null }[] = [];
  let meta: number | null = metaPadrao;
  let media: number | null = null;

  for (const r of s.rows) {
    const label = clean(r[periodoIdx]);
    if (!label) continue;
    const m = pct(col(r, s.map, "meta"));
    if (m !== null) meta = m;
    const valor = pct(col(r, s.map, "realizado"));
    if (ehTotal(label)) {
      media = valor;
      continue;
    }
    const key = monthKeyFromText(label);
    serie.push({ label: key ? monthLabel(key) : label, value: valor });
    pontos.push({ key, value: valor });
  }

  return { serie, pontos, meta, media: media ?? mediaDe(serie.map((p) => p.value)) };
}

function parseEstoque(nome: string, grid: Grid, titulo: RegExp): EstoqueArea {
  const r = lerRealizados(sectionByTitle(grid, titulo), METAS.acuracidade);
  return {
    nome,
    meta: r.meta ?? METAS.acuracidade,
    atual: atualDaData(r.pontos),
    media: r.media,
    serie: r.serie,
  };
}

function parsePerdas(grid: Grid): { perdas: NamedValue[]; meta: number; media: number | null } {
  const r = lerRealizados(sectionByTitle(grid, /perdas e extravios/i), METAS.perdas);
  const perdas: NamedValue[] = r.serie
    .filter((p) => p.value !== null)
    .map((p) => ({ label: p.label, value: p.value as number }));
  return { perdas, meta: r.meta ?? METAS.perdas, media: r.media };
}

/* ---------- RH ---------- */

function parseRhMensal(grid: Grid, titulo: RegExp, nome: string, metaPadrao: number): RhIndicador | null {
  const s = sectionByTitle(grid, titulo);
  if (!s) return null;
  const r = lerRealizados(s, metaPadrao);
  if (!r.serie.length) return null;
  return {
    nome,
    meta: r.meta,
    media: r.media,
    atual: atualDaData(r.pontos),
    percentual: true,
    serie: r.serie,
  };
}

function parseRh(grid: Grid): RhData {
  const turnover = parseRhMensal(grid, /taxa de turnover/i, "Taxa de Turnover", METAS.turnover);
  const absenteismo = parseRhMensal(
    grid,
    /taxa de absent/i,
    "Taxa de Absenteísmo",
    METAS.absenteismo,
  );

  // Feedbacks: Indicador | Tipo de Meta | Meta | Média Anual | Status
  const fb = sectionByHeader(grid, ["indicador", "tipo de meta"]);
  const feedbacks: RhIndicador[] = [];
  let feedbackMedia: number | null = null;
  let feedbackMeta: number | null = METAS.feedbacks;
  for (const r of fb?.rows ?? []) {
    const nome = col(r, fb!.map, "indicador");
    if (!nome) continue;
    const media = pct(col(r, fb!.map, "média anual"));
    const meta = pct(col(r, fb!.map, "meta"));
    if (/média total/i.test(nome)) {
      feedbackMedia = media;
      continue;
    }
    if (meta !== null) feedbackMeta = meta;
    feedbacks.push({ nome, meta, media, atual: media, percentual: true, serie: [] });
  }
  if (feedbackMedia === null) feedbackMedia = mediaDe(feedbacks.map((i) => i.media));

  // PCO / eNPS: Indicador | Polaridade | Meta | 2026 | Status
  const an = sectionByHeader(grid, ["indicador", "polaridade"]);
  const anuais: RhIndicador[] = [];
  if (an) {
    const anoIdx = an.header.findIndex((c) => /^\d{4}$/.test(clean(c)));
    const anoLabel = clean(an.header[anoIdx]);
    for (const r of an.rows) {
      const nome = col(r, an.map, "indicador");
      if (!nome) continue;
      const valor = anoIdx >= 0 ? pct(r[anoIdx]) : null;
      anuais.push({
        nome,
        meta: pct(col(r, an.map, "meta")),
        media: valor,
        atual: valor,
        percentual: true,
        serie: [{ label: anoLabel || "Ano", value: valor }],
      });
    }
  }

  const semAcento = (s: string) =>
    s
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");

  return {
    turnover,
    absenteismo,
    outros: [],
    bimestrais: feedbacks,
    anuais,
    feedbackMedia,
    feedbackMeta,
    pco: anuais.find((i) => semAcento(i.nome).includes("pco") || semAcento(i.nome).includes("clima")) ?? null,
  };
}

/* ---------- entry point ---------- */

let cache: { at: number; data: DashboardData } | null = null;
const CACHE_MS = 60_000;

export async function loadDashboard(): Promise<DashboardData> {
  if (cache && Date.now() - cache.at < CACHE_MS) return cache.data;

  const [comercial, projetos, producaoGrid, rhGrid] = (await fetchTabsSequential([
    SOURCES.comercial,
    SOURCES.projetos,
    SOURCES.producao,
    SOURCES.rh,
  ])) as [Grid, Grid, Grid, Grid];

  const areas = [
    parseEstoque("Almoxarifado", producaoGrid, /almoxarifado.*acuracidade/i),
    parseEstoque("Vidro", producaoGrid, /vidros?.*acuracidade/i),
    parseEstoque("Sodem", producaoGrid, /sodem.*acuracidade/i),
    parseEstoque("Perfil", producaoGrid, /perfil.*acuracidade/i),
    parseEstoque("Elétrico", producaoGrid, /el[ée]trico.*acuracidade/i),
  ];
  const { perdas, meta: perdasMeta, media: perdasMedia } = parsePerdas(producaoGrid);
  const atuais = areas.map((a) => a.atual).filter((v): v is number => v !== null);

  const producao: ProducaoData = {
    areas,
    perdas,
    perdasMeta,
    acuracidadeMedia: atuais.length
      ? Math.round((atuais.reduce((s, v) => s + v, 0) / atuais.length) * 10) / 10
      : null,
    perdasMedia,
  };

  const data: DashboardData = {
    atualizadoEm: new Date().toISOString(),
    comercial: parseComercial(comercial),
    projetos: parseProjetos(projetos),
    producao,
    rh: parseRh(rhGrid),
  };
  cache = { at: Date.now(), data };
  return data;
}
