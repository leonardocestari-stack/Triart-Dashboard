import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Banknote, Clock3, Send, Target } from "lucide-react";
import { dashboardQuery } from "@/lib/dashboard-query";
import { METAS } from "@/lib/dashboard-types";
import { Shell, PageTitle } from "@/components/dashboard/shell";
import { KpiCard, Panel, MetaBadge } from "@/components/dashboard/panel";
import { Columns, Donut, TrendLine } from "@/components/dashboard/charts";
import { brlCompact, dias, int, pct } from "@/components/dashboard/format";

export const Route = createFileRoute("/comercial")({
  head: () => ({
    meta: [
      { title: "Comercial · Painel TRIART" },
      {
        name: "description",
        content:
          "Taxa de conversão de leads, volume e valor de propostas enviadas e tempo médio de fechamento da área comercial.",
      },
      { property: "og:title", content: "Comercial · Painel TRIART" },
      {
        property: "og:description",
        content: "Conversão de leads, propostas enviadas e tempo médio de fechamento.",
      },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(dashboardQuery),
  component: Comercial,
  errorComponent: ({ error }) => (
    <div className="p-10 text-center text-sm font-semibold text-bad" role="alert">
      {error.message}
    </div>
  ),
  notFoundComponent: () => <div className="p-10 text-center">Página não encontrada.</div>,
});

function Comercial() {
  const { data } = useSuspenseQuery(dashboardQuery);
  const c = data.comercial;

  return (
    <Shell atualizadoEm={data.atualizadoEm}>
      <PageTitle
        title="Área Comercial"
        description="Funil de leads, propostas e fechamentos a partir da base comercial."
      />

      <div className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          icon={<Target className="h-5 w-5" />}
          tone="brand"
          label="Taxa de conversão"
          value={pct(c.taxaConversao)}
          hint={`Meta ${METAS.conversao}%`}
          status={c.taxaConversao === null ? null : c.taxaConversao >= METAS.conversao ? "good" : "bad"}
        />
        <KpiCard
          icon={<Send className="h-5 w-5" />}
          tone="sky"
          label="Propostas enviadas"
          value={int(c.propostasEnviadas)}
          hint={`${brlCompact(c.valorPropostas)} em propostas`}
        />
        <KpiCard
          icon={<Clock3 className="h-5 w-5" />}
          tone="butter"
          label="Tempo médio de fechamento"
          value={dias(c.tempoMedioFechamento)}
          hint="Da entrada do lead até a venda ganha"
        />
        <KpiCard
          icon={<Banknote className="h-5 w-5" />}
          tone="mint"
          label="Leads convertidos"
          value={int(c.convertidos)}
          hint={`${int(c.totalLeads)} leads · ${int(c.perdidos)} perdidos`}
        />
      </div>

      <Panel
        className="mt-5"
        title="Taxa de conversão de leads"
        subtitle="Evolução temporal por mês de entrada do lead"
        badge={<MetaBadge>Meta {METAS.conversao}%</MetaBadge>}
      >
        <TrendLine data={c.conversaoPorMes} meta={METAS.conversao} height={300} />
      </Panel>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <Panel
          className="lg:col-span-2"
          title="Volume de propostas enviadas"
          subtitle="Quantidade por período"
        >
          <Columns data={c.propostasPorMes} color="var(--brand)" height={300} />
        </Panel>
        <Panel title="Participação no valor de propostas" subtitle="% de cada mês no total">
          <Donut data={c.valorPropostasPorMes} formatter={brlCompact} height={300} />
        </Panel>
      </div>

      <Panel
        className="mt-5"
        title="Tempo médio de fechamento"
        subtitle="Dias entre entrada do lead e fechamento, por mês"
      >
        <TrendLine data={c.tempoFechamentoPorMes} unit=" dias" color="var(--peach)" height={280} />
      </Panel>
    </Shell>
  );
}
