import { CalendarClock, ClipboardCheck, Gauge, HeartHandshake, PackageMinus, Target, Users } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { dashboardQuery } from "@/lib/dashboard-query";
import { METAS } from "@/lib/dashboard-types";
import { Shell, PageTitle } from "@/components/dashboard/shell";
import { KpiCard, Panel, MetaBadge } from "@/components/dashboard/panel";
import { Columns, Donut } from "@/components/dashboard/charts";
import { dias, pct } from "@/components/dashboard/format";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Painel Executivo TRIART · Visão Geral" },
      {
        name: "description",
        content:
          "Dashboard automatizado da TRIART com indicadores de Comercial, Projetos, Produção e RH atualizados direto da planilha.",
      },
      { property: "og:title", content: "Painel Executivo TRIART · Visão Geral" },
      {
        property: "og:description",
        content: "Indicadores de Comercial, Projetos, Produção e RH em tempo quase real.",
      },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(dashboardQuery),
  component: VisaoGeral,
  errorComponent: ({ error }) => (
    <div className="p-10 text-center text-sm font-semibold text-bad" role="alert">
      {error.message}
    </div>
  ),
  notFoundComponent: () => <div className="p-10 text-center">Página não encontrada.</div>,
});

function VisaoGeral() {
  const { data } = useSuspenseQuery(dashboardQuery);
  const { comercial, projetos, producao, rh } = data;

  const status = (v: number | null | undefined, meta: number, maior = true) =>
    v === null || v === undefined ? null : (maior ? v >= meta : v <= meta) ? ("good" as const) : ("bad" as const);

  const metaTurnover = rh.turnover?.meta ?? METAS.turnover;
  const metaFeedback = rh.feedbackMeta ?? METAS.feedbacks;
  const metaPco = rh.pco?.meta ?? METAS.pco;

  const acuracidadeMedia = producao.areas
    .filter((a) => a.media !== null)
    .map((a) => ({ label: a.nome, value: a.media as number }));

  const metaAcuracidade = producao.areas[0]?.meta ?? METAS.acuracidade;

  const pendentes = Math.max(projetos.solicitados - projetos.finalizados, 0);
  const pizzaProjetos = projetos.solicitados
    ? [
        { label: "Finalizados", value: projetos.finalizados },
        { label: "Em andamento", value: pendentes },
      ]
    : [];

  return (
    <Shell atualizadoEm={data.atualizadoEm}>
      <PageTitle
        title="Visão geral da operação"
        description="Indicadores essenciais das quatro áreas, lidos direto das planilhas e atualizados a cada 5 minutos."
      />

      <div className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          icon={<Target className="h-5 w-5" />}
          tone="brand"
          label="Taxa de conversão de leads"
          value={pct(comercial.taxaConversao)}
          hint={`Meta ${METAS.conversao}%`}
          status={status(comercial.taxaConversao, METAS.conversao)}
        />
        <KpiCard
          icon={<CalendarClock className="h-5 w-5" />}
          tone="peach"
          label="Tempo médio de fechamento"
          value={dias(comercial.tempoMedioFechamento)}
          hint="Da entrada do lead à venda ganha"
        />
        <KpiCard
          icon={<PackageMinus className="h-5 w-5" />}
          tone="sky"
          label="Perdas e extravios (média anual)"
          value={pct(producao.perdasMedia)}
          hint={`Meta ${producao.perdasMeta}%`}
          status={status(producao.perdasMedia, producao.perdasMeta, false)}
        />
        <KpiCard
          icon={<Users className="h-5 w-5" />}
          tone="mint"
          label="Turnover"
          value={pct(rh.turnover?.atual ?? null)}
          hint={`Meta ${metaTurnover}%`}
          status={status(rh.turnover?.atual, metaTurnover, false)}
        />
      </div>

      <div className="mt-5 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          icon={<ClipboardCheck className="h-5 w-5" />}
          tone="butter"
          label="Feedbacks realizados (média)"
          value={pct(rh.feedbackMedia)}
          hint={`Meta ${metaFeedback}%`}
          status={status(rh.feedbackMedia, metaFeedback)}
        />
        <KpiCard
          icon={<HeartHandshake className="h-5 w-5" />}
          tone="peach"
          label="PCO · Pesquisa de clima"
          value={pct(rh.pco?.atual ?? null)}
          hint={`Meta ${metaPco}%`}
          status={status(rh.pco?.atual, metaPco)}
        />
        <KpiCard
          icon={<Gauge className="h-5 w-5" />}
          tone="sky"
          label="Acuracidade média de estoque"
          value={pct(producao.acuracidadeMedia)}
          hint={`Meta ${metaAcuracidade}%`}
          status={status(producao.acuracidadeMedia, metaAcuracidade)}
        />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Panel title="Projetos finalizados" subtitle="Participação sobre o total de projetos solicitados">
          <Donut data={pizzaProjetos} formatter={(v) => `${v.toLocaleString("pt-BR")} projetos`} />
        </Panel>
        <Panel
          title="Acuracidade de estoque por segmento"
          subtitle="Média anual de cada frente"
          badge={<MetaBadge>Meta {metaAcuracidade}%</MetaBadge>}
        >
          <Columns
            data={acuracidadeMedia}
            meta={metaAcuracidade}
            metaDirecao="min"
            unit="%"
            color="var(--brand)"
          />
        </Panel>
      </div>
    </Shell>
  );
}
