import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { PackageCheck } from "lucide-react";
import { dashboardQuery } from "@/lib/dashboard-query";
import { Shell, PageTitle } from "@/components/dashboard/shell";
import { KpiCard, Panel, MetaBadge } from "@/components/dashboard/panel";
import { Columns, TrendLine } from "@/components/dashboard/charts";
import { pct } from "@/components/dashboard/format";

export const Route = createFileRoute("/producao")({
  head: () => ({
    meta: [
      { title: "Produção · Painel TRIART" },
      {
        name: "description",
        content:
          "Acuracidade de estoque de Almoxarifado, Vidro, Sodem, Perfil e Elétrico, além de perdas e extravios por evento.",
      },
      { property: "og:title", content: "Produção · Painel TRIART" },
      {
        property: "og:description",
        content: "Acuracidade de estoque por frente e perdas/extravios por evento.",
      },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(dashboardQuery),
  component: Producao,
  errorComponent: ({ error }) => (
    <div className="p-10 text-center text-sm font-semibold text-bad" role="alert">
      {error.message}
    </div>
  ),
  notFoundComponent: () => <div className="p-10 text-center">Página não encontrada.</div>,
});

const CORES = ["var(--brand)", "var(--peach)", "var(--sky)", "var(--mint)", "var(--brand-deep)"];

function Producao() {
  const { data } = useSuspenseQuery(dashboardQuery);
  const prod = data.producao;

  return (
    <Shell atualizadoEm={data.atualizadoEm}>
      <PageTitle
        title="Área de Produção"
        description="Acuracidade do estoque por frente e participação das perdas e extravios no valor total."
      />

      <div className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-5">
        {prod.areas.map((a, i) => (
          <KpiCard
            key={a.nome}
            icon={<PackageCheck className="h-5 w-5" />}
            tone={(["brand", "peach", "sky", "mint", "butter"] as const)[i] ?? "brand"}
            label={`Acuracidade ${a.nome}`}
            value={pct(a.atual)}
            hint={`Meta ${a.meta}%`}
            status={a.atual === null ? null : a.atual >= a.meta ? "good" : "bad"}
          />
        ))}
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        {prod.areas.map((a, i) => (
          <Panel
            key={a.nome}
            title={`Acuracidade ${a.nome}`}
            subtitle="Evolução do estoque por período"
            badge={<MetaBadge>Meta {a.meta}%</MetaBadge>}
          >
            <TrendLine data={a.serie} meta={a.meta} color={CORES[i % CORES.length] ?? "var(--brand)"} />
          </Panel>
        ))}
        <Panel
          title="Perdas e extravios"
          subtitle="% do valor de perdas sobre o valor total do estoque, por evento"
          badge={<MetaBadge>Meta {prod.perdasMeta}%</MetaBadge>}
        >
          <Columns data={prod.perdas} meta={prod.perdasMeta} unit="%" color="var(--brand)" />
        </Panel>
      </div>
    </Shell>
  );
}
