import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ChartNoAxesColumnIncreasing, CircleCheckBig, FileInput, PencilLine } from "lucide-react";
import { dashboardQuery } from "@/lib/dashboard-query";
import { Shell, PageTitle } from "@/components/dashboard/shell";
import { KpiCard, Panel } from "@/components/dashboard/panel";
import { Columns, Donut, TrendLine } from "@/components/dashboard/charts";
import { int, pct } from "@/components/dashboard/format";

export const Route = createFileRoute("/projetos")({
  head: () => ({
    meta: [
      { title: "Projetos · Painel TRIART" },
      {
        name: "description",
        content:
          "Projetos solicitados e finalizados, percentual de conclusão e volume de alterações por mês.",
      },
      { property: "og:title", content: "Projetos · Painel TRIART" },
      {
        property: "og:description",
        content: "Finalização de projetos e alterações mês a mês.",
      },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(dashboardQuery),
  component: Projetos,
  errorComponent: ({ error }) => (
    <div className="p-10 text-center text-sm font-semibold text-bad" role="alert">
      {error.message}
    </div>
  ),
  notFoundComponent: () => <div className="p-10 text-center">Página não encontrada.</div>,
});

function Projetos() {
  const { data } = useSuspenseQuery(dashboardQuery);
  const p = data.projetos;
  const pendentes = Math.max(p.solicitados - p.finalizados, 0);

  return (
    <Shell atualizadoEm={data.atualizadoEm}>
      <PageTitle
        title="Área de Projetos"
        description="Finalização e alterações de projetos acumuladas em todos os períodos preenchidos."
      />

      <div className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard icon={<FileInput className="h-5 w-5" />} tone="brand" label="Projetos solicitados" value={int(p.solicitados)} hint="Todos os períodos" />
        <KpiCard icon={<CircleCheckBig className="h-5 w-5" />} tone="mint" label="Projetos finalizados" value={int(p.finalizados)} hint="Todos os períodos" />
        <KpiCard icon={<ChartNoAxesColumnIncreasing className="h-5 w-5" />} tone="peach" label="% Finalizados" value={pct(p.percFinalizados)} hint="Finalizados sobre solicitados" />
        <KpiCard icon={<PencilLine className="h-5 w-5" />} tone="butter" label="Alterações" value={int(p.alteracoes)} hint="Total de alterações registradas" />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <Panel title="Finalizados vs pendentes" subtitle="Participação no total solicitado">
          <Donut
            data={[
              { label: "Finalizados", value: p.finalizados },
              { label: "Não finalizados", value: pendentes },
            ]}
            formatter={(v) => `${int(v)} projetos`}
            height={300}
          />
        </Panel>
        <Panel
          className="lg:col-span-2"
          title="% Finalizados vs Solicitados"
          subtitle="Evolução ao longo dos meses"
        >
          <TrendLine data={p.percPorMes} color="var(--brand)" height={300} />
        </Panel>
      </div>

      <Panel className="mt-5" title="Alterações de projetos" subtitle="Número de alterações por período">
        <Columns data={p.alteracoesPorMes} color="var(--peach)" height={300} />
      </Panel>
    </Shell>
  );
}
