import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { CalendarClock, RefreshCcw } from "lucide-react";
import { dashboardQuery } from "@/lib/dashboard-query";
import { METAS } from "@/lib/dashboard-types";
import { Shell, PageTitle } from "@/components/dashboard/shell";
import { KpiCard, Panel, MetaBadge, EmptyState } from "@/components/dashboard/panel";
import { TrendLine } from "@/components/dashboard/charts";
import { pct, int } from "@/components/dashboard/format";

export const Route = createFileRoute("/rh")({
  head: () => ({
    meta: [
      { title: "RH · Painel TRIART" },
      {
        name: "description",
        content: "Evolução mensal da taxa de turnover e da taxa de absenteísmo frente às metas de RH.",
      },
      { property: "og:title", content: "RH · Painel TRIART" },
      { property: "og:description", content: "Turnover e absenteísmo mês a mês." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(dashboardQuery),
  component: Rh,
  errorComponent: ({ error }) => (
    <div className="p-10 text-center text-sm font-semibold text-bad" role="alert">
      {error.message}
    </div>
  ),
  notFoundComponent: () => <div className="p-10 text-center">Página não encontrada.</div>,
});

function Rh() {
  const { data } = useSuspenseQuery(dashboardQuery);
  const { turnover, absenteismo, outros, bimestrais, anuais } = data.rh;
  const metaTurnover = turnover?.meta ?? METAS.turnover;
  const metaAbsent = absenteismo?.meta ?? METAS.absenteismo;

  const listas: [string, string, typeof outros][] = [
    ["Outros indicadores mensais", "Média anual por indicador", outros],
    ["Indicadores bimestrais", "Média do ano por indicador", bimestrais],
    ["Indicadores anuais", "Resultado do ano por indicador", anuais],
  ];

  return (
    <Shell atualizadoEm={data.atualizadoEm}>
      <PageTitle
        title="Área de RH"
        description="Indicadores de pessoas mês a mês, comparados às metas definidas na base."
      />

      <div className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          icon={<RefreshCcw className="h-5 w-5" />}
          tone="brand"
          label="Turnover atual"
          value={pct(turnover?.atual ?? null)}
          hint={`Meta ${metaTurnover}% · média anual ${pct(turnover?.media ?? null)}`}
          status={
            turnover?.atual === undefined || turnover?.atual === null
              ? null
              : turnover.atual <= metaTurnover
                ? "good"
                : "bad"
          }
        />
        <KpiCard
          icon={<CalendarClock className="h-5 w-5" />}
          tone="mint"
          label="Absenteísmo atual"
          value={pct(absenteismo?.atual ?? null)}
          hint={`Meta ${metaAbsent}% · média anual ${pct(absenteismo?.media ?? null)}`}
          status={
            absenteismo?.atual === undefined || absenteismo?.atual === null
              ? null
              : absenteismo.atual <= metaAbsent
                ? "good"
                : "bad"
          }
        />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Panel
          title="Taxa de turnover"
          subtitle="Evolução temporal mês a mês"
          badge={<MetaBadge>Meta {metaTurnover}%</MetaBadge>}
        >
          {turnover ? (
            <TrendLine data={turnover.serie} meta={metaTurnover} height={300} />
          ) : (
            <EmptyState message="Indicador de turnover ainda não preenchido na base de RH." />
          )}
        </Panel>
        <Panel
          title="Taxa de absenteísmo"
          subtitle="Evolução temporal mês a mês"
          badge={<MetaBadge>Meta {metaAbsent}%</MetaBadge>}
        >
          {absenteismo ? (
            <TrendLine
              data={absenteismo.serie}
              meta={metaAbsent}
              color="var(--peach)"
              height={300}
            />
          ) : (
            <EmptyState message="Indicador de absenteísmo ainda não preenchido na base de RH." />
          )}
        </Panel>
      </div>

      {listas.map(([titulo, subtitulo, itens]) =>
        itens.length ? (
          <Panel key={titulo} className="mt-5" title={titulo} subtitle={subtitulo}>
            <ul className="divide-y divide-border">
              {itens.map((i) => {
                const fmt = (v: number | null) => (i.percentual ? pct(v) : int(v));
                return (
                  <li key={i.nome} className="flex items-center justify-between gap-4 py-3 text-sm font-semibold">
                    <span>{i.nome}</span>
                    <span className="text-right text-mute">
                      {fmt(i.media ?? i.atual)} {i.meta !== null ? `· meta ${fmt(i.meta)}` : ""}
                    </span>
                  </li>
                );
              })}
            </ul>
          </Panel>
        ) : null,
      )}
    </Shell>
  );
}
